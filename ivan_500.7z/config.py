config = {
    'WIN_SIZE': (1280, 720),
    'NUM_MIN': 1,
    'NUM_MAX': 512,
    'TOKENS': 5, # части выражения. Операнды = операторы + 1. Т.е. операторов на 1 меньше
    'T_INTOPRE': 1, #1.1
    'T_INTOPOST': 1, #1.2
    'T_PRETOIN': 1, #2.1
    'T_PRETOPOST': 1, #2.2
    'T_POSTTOIN': 1, #3.1
    'T_POSTTOPRE': 1, #3.2
    'IP': 'localhost',
    'TIME': 60, # минуты
    'VRATES': [ # визуальные оценки
        90, # 5
        70, # 4
        50, # 3
        0, # 2
        0 # 1
    ]
}