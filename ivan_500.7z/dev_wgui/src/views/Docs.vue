<template>
	<div>
		<img alt="Vue logo" src="../assets/logo.png" style="width: 200px"><span style="font-size: 120pt">igul'</span>
		<h1>Доброе утро</h1>
		Сюда вставлять документацию юзера.
	</div>
</template>

<script>
// @ is an alias to /src

export default {
	name: 'Docs'
}
</script>

<style scoped>
	h3 {
		margin: 40px 0 0;
	}
	ul {
		list-style-type: none;
		padding: 0;
	}
	li {
		display: inline-block;
		margin: 0 10px;
	}
	a {
		color: #42b983;
	}
</style>