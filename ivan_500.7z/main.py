import eel
from random import randint
from pprint import pprint

from pairs import pairs
import example as ex
from config import config as CONFIG

PRODUCTION = True

eel.init('wgui')
eel.start('', block=False, size=CONFIG['WIN_SIZE'])

@eel.expose
def WindowClose():
	exit()

lastSentTest = [None]
name, group = '', ''

bikvi = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'

tokens = CONFIG['TOKENS']
def GenTask(text, lQuestion, lCorrectAnswer):
	global tokens
	nums, cnums = 0, 0
	ops = 0
	stack = []
	for j in range(tokens):
		if nums > ops and cnums > 1 and bool(randint(0, 1)) or nums - ops >= tokens - j:
			stack.append('+-*/'[randint(0, 3)])
			ops += 1
			cnums -= 1
		else:
			stack.append(bikvi[nums])
			nums += 1
			cnums += 1

	t = {}
	t['answer'] = None
	t['text'] = text
	t['question'] = lQuestion(stack)
	print(stack[::-1])
	t['correctAnswer'] = lCorrectAnswer(stack)
	return t

@eel.expose
def GetTime():
	return CONFIG['TIME']

@eel.expose
def GenTest(_name, _group, train): # генерируем тесты
	global name, group
	name, group = _name, _group
	rs = []
	for _ in range(CONFIG['T_INTOPRE']): #1.1
		rs.append(GenTask(
			'Введите префиксную запись для ',
			lambda stack: PrefixToInfix(stack[::-1]),
			lambda stack: ' '.join(stack[::-1])
		))
	for _ in range(CONFIG['T_INTOPOST']): #1.2
		rs.append(GenTask(
			'Введите постфиксную запись для ',
			lambda stack: PostfixToInfix(stack),
			lambda stack: ' '.join(stack)
		))
	for _ in range(CONFIG['T_PRETOIN']): #2.1
		rs.append(GenTask(
			'Введите инфиксную запись для ',
			lambda stack: ' '.join(stack[::-1]),
			lambda stack: PrefixToInfix(stack[::-1])
		))
	for _ in range(CONFIG['T_PRETOPOST']): #2.2
		rs.append(GenTask(
			'Введите постфиксную запись для ',
			lambda stack: ' '.join(stack[::-1]),
			lambda stack: PrefixToPostfix(stack[::-1])
		))
	for _ in range(CONFIG['T_POSTTOIN']): #3.1
		rs.append(GenTask(
			'Введите инфиксную запись для ',
			lambda stack: ' '.join(stack),
			lambda stack: PostfixToInfix(stack)
		))
	for _ in range(CONFIG['T_POSTTOPRE']): #3.1
		rs.append(GenTask(
			'Введите префиксную запись для ',
			lambda stack: PrefixToPostfix(stack[::-1]),
			lambda stack: ' '.join(stack[::-1])
		))
	global lastSentTest
	lastSentTest = []
	for v in rs:
		lastSentTest.append(dict(v))
	if not train:
		for i in range(len(rs)):
			rs[i]['correctAnswer'] = None
	print(lastSentTest)
	return rs

@eel.expose
def Judge(test, train):
	global lastSentTest
	total = len(lastSentTest)
	done = 0
	tasks = [] # выходная таблица, для GUI (!)
	for i in range(len(lastSentTest)):
		v = lastSentTest[i]
		ok = isinstance(test[i]['answer'], str) and test[i]['answer'].strip().replace(' ', '').upper() == v['correctAnswer'].replace(' ', '') # верность ответа
		lastSentTest[i]['answer'] = test[i]['answer'] # пишем ответ в выход
		if ok:
			done += 1
		tasks.append({
			'answer': test[i]['answer'],
			'correctAnswer': v['correctAnswer'],
			'correct': ok
		})
	mark = done / total
	if not train:
		# print(tasks)
		ex.SendToServer(CONFIG['IP'], name, group, mark, lastSentTest)
	vmark = 0
	for i, threshold in pairs(CONFIG['VRATES']):
		print(i)
		if mark * 100 >= threshold:
			vmark = 5 - i
			break
	return { 'tasks': tasks, 'mark': mark, 'vmark': vmark }

def PrefixToInfix(expr):
	expr = expr[::-1]
	stack = []
	for token in expr:
		if token == '+':
			a, b = stack.pop(), stack.pop()
			stack.append(f'({a} + {b})')
		elif token == '-':
			a, b = stack.pop(), stack.pop()
			stack.append(f'({a} - {b})')
		elif token == '*':
			a, b = stack.pop(), stack.pop()
			stack.append(f'({a} * {b})')
		elif token == '/':
			a, b = stack.pop(), stack.pop()
			stack.append(f'({a} / {b})')
		else:
			stack.append(token)
	r = stack.pop()
	r = r[1:len(r) - 1]
	return r

def PostfixToInfix(expr):
	stack = []
	for token in expr:
		if token == '+':
			b, a = stack.pop(), stack.pop()
			stack.append(f'({a} + {b})')
		elif token == '-':
			b, a = stack.pop(), stack.pop()
			stack.append(f'({a} - {b})')
		elif token == '*':
			b, a = stack.pop(), stack.pop()
			stack.append(f'({a} * {b})')
		elif token == '/':
			b, a = stack.pop(), stack.pop()
			stack.append(f'({a} / {b})')
		else:
			stack.append(token)
	r = stack.pop()
	r = r[1:len(r) - 1]
	return r

def PrefixToPostfix(expr):
	expr = expr[::-1]
	stack = []
	for token in expr:
		if token in set('+-*/'):
			a, b = stack.pop(), stack.pop()
			stack.append(' '.join([a, b, token]))
		else:
			stack.append(token)
	return ' '.join(stack)

print(PostfixToInfix('5 6 - 7 *'.split()))
print(PrefixToInfix('* - 5 6 7'.split()))
print(PrefixToPostfix('* - 5 6 7'.split()))
# GenTest('_name', '_group', True)

while True:
	eel.sleep(10)